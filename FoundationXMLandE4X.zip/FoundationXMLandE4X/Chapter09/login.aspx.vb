Imports System.IO
Imports System.Xml

Partial Class login
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim strUsername As String = "sas"
        Dim strPassword As String = "secret"
        Dim strSuppliedUsername As String = Request.Form("username")
        Dim strSuppliedPassword As String = Request.Form("password")
        Dim strResponse As String = ""
        Dim loginResponse As XmlTextWriter = New XmlTextWriter(Response.OutputStream, Encoding.UTF8)
        If StrComp(strUsername, strSuppliedUsername) = 0 Then
            If StrComp(strPassword, strSuppliedPassword) = 0 Then
                strResponse = "true"
            Else
                strResponse = "false"
            End If
        Else
            strResponse = "false"
        End If
        Response.ContentType = "text/xml"
        loginResponse.WriteStartDocument()
        loginResponse.WriteStartElement("loginResult")
        loginResponse.WriteValue(strResponse)
        loginResponse.WriteEndElement()
        loginResponse.Flush()
        loginResponse.Close()
    End Sub
End Class
