<?php
	header('Content-Type:text/xml');
	$strUsername = 'sas';
	$strPassword = 'secret';
	$strSuppliedUsername = '';
	$strSuppliedPassword = '';
	if (isset($_POST['username'])) {
		$strSuppliedUsername = $_POST['username'];
	}
	if (isset($_POST['password'])) {
		$strSuppliedPassword = $_POST['password'];
	}
	if (strcasecmp($strUsername, $strSuppliedUsername) == 0) {
	  if (strcasecmp($strPassword, $strSuppliedPassword) == 0) {
		$strResponse = 'true';
	  }
	  else {
	  	$strResponse = 'false';
	  }
	}
    else {
	  	$strResponse = 'false';
	}
	$loginResponse = new DomDocument('1.0', 'UTF-8');
	$root = $loginResponse->createElement('loginResult', $strResponse);
	$root = $loginResponse->appendChild($root);
	echo $loginResponse->saveXML();
?>
