<?php
header('Content-Type: text/xml');
include 'dbConn.php';

$xml = new DomDocument('1.0', 'UTF-8');
$root = $xml->createElement('phoneBook');
$root = $xml->appendChild($root);
$sql = 'SELECT * FROM phoneBook ORDER BY contactname ';
$result = mysql_query($sql);
if ($result) {
  if (mysql_num_rows($result) > 0) {
    while ($row = mysql_fetch_array($result)) {
      $name = $row['contactName'];
      $address = $row['address'];
      $phone = $row['phone'];
      $contactElement = $xml->createElement('contact');
      $contactElement = $rootElement->appendChild($contactElement);
      $nameElement = $xml->createElement('name',$name);
      $nameElement = $contactElement->appendChild($nameElement);
      $addressElement = $xml->createElement('address', $address);
      $addressElement = $contactElement->appendChild($addressElement);
      $phoneElement = $xml->createElement('phone', $phone);
      $phoneElement = $contactElement->appendChild($phoneElement);
    }
  }
echo $xml->saveXML();
?>

