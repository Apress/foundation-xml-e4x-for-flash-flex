Imports System.IO
Imports System.Xml
Imports System.Data
Imports System.Data.OleDb

Partial Class getAddresses
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim dbConnString As String = ConfigurationManager.ConnectionStrings("addresses").ConnectionString()
        Dim dbConn As New OleDbConnection(dbConnString)
        Dim objCommand As OleDbCommand
        Dim objDataReader As OleDbDataReader
        Dim strSQL As String
        Dim addressesXMLDoc As XmlTextWriter = New XmlTextWriter(Response.OutputStream, Encoding.UTF8)
        Response.ContentType = "text/xml"
        strSQL = "SELECT * FROM phoneBook ORDER BY contactname"
        dbConn.Open()
        objCommand = New OleDbCommand(strSQL, dbConn)
        objDataReader = objCommand.ExecuteReader()
        addressesXMLDoc.Formatting = Formatting.Indented
        addressesXMLDoc.WriteStartDocument()
        addressesXMLDoc.WriteStartElement("phoneBook")
        While objDataReader.Read()
            addressesXMLDoc.WriteStartElement("contact")
      addressesXMLDoc.WriteAttributeString("id", objDataReader("ID"))
            addressesXMLDoc.WriteStartElement("name")
            addressesXMLDoc.WriteValue(objDataReader("contactname"))
            addressesXMLDoc.WriteEndElement()
            addressesXMLDoc.WriteStartElement("address")
            addressesXMLDoc.WriteCData(objDataReader("address"))
            addressesXMLDoc.WriteEndElement()
            addressesXMLDoc.WriteStartElement("phone")
            addressesXMLDoc.WriteValue(objDataReader("phone"))
            addressesXMLDoc.WriteEndElement()
            addressesXMLDoc.WriteEndElement()
        End While
        addressesXMLDoc.WriteEndElement()
        addressesXMLDoc.Flush()
        addressesXMLDoc.Close()
        objDataReader.Close()
        dbConn.Close()
    End Sub

End Class
